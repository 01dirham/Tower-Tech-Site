export async function handler(event, context) {
  try {
    const body = JSON.parse(event.body || "{}");
    const payload = body.payload || body;
    const data = payload.data || {};
    const formName = (payload.form_name || payload.formName || "unknown").toLowerCase();

    // ENV + defaults
    const RESEND_API_KEY = process.env.RESEND_API_KEY;
    const TO_EMAIL       = process.env.TO_EMAIL || "anatolijsavenko579@gmail.com";
    const FROM_EMAIL     = process.env.FROM_EMAIL || "noreply@dirhamstudio.com";

    if (!RESEND_API_KEY) {
      console.error("Missing RESEND_API_KEY env var.");
      return { statusCode: 500, body: "Missing RESEND_API_KEY" };
    }

    const isLearn = formName.includes("learn");
    const isWork  = formName.includes("work");
    const subj = isLearn
      ? "Nowe zgłoszenie: SZKOLENIE (Tower Tech)"
      : isWork ? "Nowe zgłoszenie: PRACA (Tower Tech)"
               : `Nowe zgłoszenie: ${formName}`;

    const labels = {
      name:"Imię i nazwisko",
      phone:"Telefon",
      email:"Email",
      city:"Miasto",
      polish:"Poziom PL",
      experience:"Doświadczenie",
      udt:"UDT/certyfikat",
      cranes:"Żurawie",
      comment:"Komentarz",
      consent:"Zgoda RODO"
    };
    const rows = Object.entries(data).map(([k,v])=>{
      const label = labels[k] || k;
      const val = (Array.isArray(v) ? v.join(", ") : (v ?? "")).toString();
      return `<tr><td style="padding:8px 12px;background:#0e1116;color:#e9eef1;border-bottom:1px solid #1b2129;"><strong>${label}</strong></td><td style="padding:8px 12px;background:#0b0f14;color:#cfd9e3;border-bottom:1px solid #1b2129;">${val}</td></tr>`;
    }).join("");

    const html = `
      <div style="font-family:Montserrat,Segoe UI,Arial,sans-serif;background:#0a0f14;padding:16px;color:#e9eef1">
        <h2 style="margin:0 0 10px 0">Tower Tech — nowa wiadomość z formularza</h2>
        <p style="margin:0 0 16px 0">Formularz: <strong>${formName}</strong></p>
        <table style="border-collapse:collapse;width:100%;max-width:720px">${rows}</table>
        <p style="color:#93a0ad;font-size:12px;margin-top:16px">ID: ${payload.id || "-"} | Data: ${payload.created_at || new Date().toISOString()}</p>
      </div>
    `;

    const adminRes = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Authorization": `Bearer ${RESEND_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from: FROM_EMAIL, to: TO_EMAIL, subject: subj, html })
    });
    if (!adminRes.ok) {
      const t = await adminRes.text();
      console.error("Resend admin error:", t);
      return { statusCode: 502, body: "Email send failed (admin)" };
    }

    const userEmail = data.email;
    if (userEmail) {
      const userHtml = `
        <div style="font-family:Montserrat,Segoe UI,Arial,sans-serif;background:#0a0f14;padding:16px;color:#e9eef1">
          <h2 style="margin:0 0 10px 0">Dziękujemy za zgłoszenie!</h2>
          <p>Otrzymaliśmy Twoje dane. Skontaktujemy się wkrótce.</p>
          <p style="color:#93a0ad;font-size:12px">Tower Tech</p>
        </div>
      `;
      await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { "Authorization": `Bearer ${RESEND_API_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify({ from: FROM_EMAIL, to: userEmail, subject: isLearn ? "Twoje zgłoszenie — szkolenie Tower Tech" : "Twoje zgłoszenie — praca Tower Tech", html: userHtml })
      }).catch(e=>console.error("Resend user error:", e));
    }

    return { statusCode: 200, body: "OK" };
  } catch(e) {
    console.error("Handler error:", e);
    return { statusCode: 500, body: "Server error" };
  }
}
